# Luna — instalador desde cero

Luna es un proyecto para poner fondos de pantalla animados, fácil y sin plugins.

## Qué hay aquí

- `luna.py` — app mínima: `luna set video.mp4`, `luna stop`, `luna list`, `luna status`
- `install.sh` — instalador universal, detecta Arch o Debian/Ubuntu
- `PKGBUILD` — para Arch / Pacman
- `build-deb.sh` + `debian/` — para Debian / Ubuntu (.deb)
- `luna.desktop` y `luna.service` — acceso y autostart

## Instalar rápido

```bash
chmod +x install.sh
sudo ./install.sh
mkdir -p ~/Videos/Luna
# copia un video ahí y luego:
luna set ~/Videos/Luna/tu-video.mp4
```

## Arch (Pacman)

```bash
makepkg -si
# o: sudo pacman -U luna-1.0-1-any.pkg.tar.zst
```

## Debian / Ubuntu (.deb)

```bash
chmod +x build-deb.sh
./build-deb.sh
sudo dpkg -i luna_1.0_all.deb
sudo apt -f install
```

## Notas

- Wayland: necesita `mpvpaper`. X11: necesita `xwinwrap`.
- En Arch, `mpvpaper` está en AUR: `yay -S mpvpaper`.
- Pon tus videos en `~/Videos/Luna/`.
