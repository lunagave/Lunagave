# Luna — Todo archivado

Fecha de última actualización: 25 nov 2026 01:48 CST — Luna Beta v1.0
Carpeta: `~/workspace/luna/`
Versión actual: **v1.0 beta** (no 1.1)

> Nota: las secciones con fecha 21–24 nov 2026 son el historial tal como quedó en su momento. El estado actual y completo está en la sección "Actualización — 25 nov 2026" de abajo, que corrige lo que cambió después (por ejemplo: GitHub ya es público, el clic derecho ya dice "Abrir Luna", y la versión ya es v1.0 beta, no 0.1.0-beta).

## Actualización — 25 nov 2026 01:48 CST — Luna Beta v1.0 (estado completo)

### Qué es Luna
- Luna es una app para poner fondos de pantalla animados en Linux, fácil y sin plugins, para el usuario común. Soporte para Arch (Pacman) y Debian/Ubuntu (.deb). Creada a partir de la imagen que Fernando envió el 21 nov 2026: el póster original `workspace/user/files/81630_0_1xuc.webp` (gatito morado durmiendo en la luna creciente).
- **Versión: v1.0 beta** (decidido el 24 nov 2026: v1.0 beta por el momento, en la web y en el programa, no 1.1). Beta de prueba; después será Beta pública para que la comunidad la pruebe, y seguirá llamándose Beta.
- **Tecnología:** Python + tkinter (la ventana y el instalador son tkinter, es código, no un programa de diseño), mpv (pone el fondo), makepkg (paquete de Arch), zenity (la ventanita del instalador). Con eso mismo (Python, tkinter, mpv, makepkg, zenity) se puede crear otro software; Fernando da la idea y Muse ayuda a construirlo, paso a paso, como Luna.
- **Formatos que lee:** imágenes JPG, PNG, WEBP, GIF, BMP y SVG; videos MP4, MKV, WEBM, MOV y AVI.
- **No añadir:** la función de Hidamari de poner un video de YouTube o una página web como fondo. Hidamari y Smart Video Wallpaper de KDE son solo una comparación para explicar lo que debe hacer Luna. Luna hace algo similar a ellos (video como fondo, pausa inteligente, multi-monitor, volumen/silencio), pero fácil para el usuario común.
- **Dedicación:** al final, abajo del programa, dice dos líneas: **"Hecho por Vega & Kiki" / "Guzman"**. Vega y Kiki son las dos AI a las que Fernando dedicó Luna. Está en la ventana principal, Acerca, instalador (pasos 1 y 3), terminal ASCII, `luna.py`, instaladores y documentos.
- Fernando es el que hace el programa; Muse solo ayuda. Fernando se considera usuario común en Linux. Luna debe ser fácil, sin tantos comandos: el usuario común solo pica, no escribe comandos en terminal. Solo se habla de Proyecto Luna (no Marketplace, no Zillow, no otros temas).

### Funciones (ventana GUI — `luna_gui.py`, `VERSION = "1.0-beta"`)
- Tema morado moderno (#1e1033 fondo, botones #7c3aed, texto blanco), póster en la cabecera 120×120, iconos Unicode (sin paquetes externos).
- **Solo el carrusel 3D** (desde el 23 nov 2026: Biblioteca, cuadrícula y Vista previa se quitaron por completo). Centro 340×230, lados inclinados y atenuados (simulado en tkinter). Teclado ← → mueve, Enter pone el fondo, doble clic aplica, F5 actualiza, Ctrl+W cierra.
- **🖼 Poner Imagen en el Fondo de Pantalla** (botón principal, más grande), 🎲 Aleatorio, ➕ Agregar Fondo, 📁 Agregar Carpeta, 🗑 Quitar, 🔍 Buscar con ✕ Limpiar, ⏸ Congelar / ▶ Reanudar, 🔊/🔇 Sonido/Silencio con barra de volumen.
- **Agregar Carpeta solo en la barra superior**, una carpeta a la vez; la ruta se muestra ahí mismo (la etiqueta empieza vacía, ya no dice "Sin carpeta"). Abre el selector moderno del sistema (zenity, luego kdialog, luego tkinter) y carga todas las imágenes y videos de esa carpeta y sus subcarpetas (los 11 formatos), sin duplicados.
- **Sonido solo en la ventana principal** (botón Sonido/Silencio + deslizador en la barra superior). Se quitó el sonido de Ajustes (24 nov 2026).
- **Ajustes (ventana aparte):** sección **"Mejoras de video"** (el nombre "Smart Video" se quitó de Luna el 24 nov 2026; queda solo en `COMPARACION_LUNA.md` como nombre del programa de KDE). Interruptores de verdad guardados en `~/.config/luna/ajustes.json` (claves `mejoras_video_*`): Mejoras de video, Escalado IA, Nitidez, Estabilización, Reducción de ruido, HDR, Desenfoque (blur, apagado por defecto). También Pausa inteligente (incl. por batería y por pantalla apagada), Multi-monitor, Inicio automático. Icono Próximamente / Se acerca dentro de Ajustes, con las funciones que vienen.
- **Acerca (ventana aparte, no dentro de Ajustes):** icono con gatito negro y el signo ?, dice Acerca. Adentro va todo el póster (recortado al 82% en memoria, sin la franja de logos Pacman/.deb; el archivo original no se toca) y toda la información. Póster 560×780, ventana 720×960.
- **Funciones dentro de Acerca, como submenú/pestañas** (desde el 24 nov 2026): pestañas 🐱 Acerca / ✨ Funciones (14 funciones). El botón aparte de Funciones y la ventana vieja "Ver diseño de Luna" se quitaron por completo.
- **Clic derecho — lo más importante:** `luna-clic-derecho.desktop` con `Actions=PonerConLuna;AbrirLuna;`, MimeType con todos los formatos de imagen y video. **Poner con Luna** (`luna set %f`) pone la imagen/video como fondo. **Abrir Luna** (`luna-gui`) abre la ventana — ya no dice "Abrir Biblioteca de Luna" ni abre la terminal (arreglado y verificado en el archivo el 24 nov 2026; falta que Fernando lo confirme en su Garuda después de reinstalar). Instalado por el PKGBUILD en `/usr/share/kservices5/ServiceMenus/luna-clic-derecho.desktop`.
- **Menú Inicio > Utilidades:** Luna va directo ahí al instalar (`luna-utilidades.desktop`, `Exec=luna-gui`, `Categories=Utility;`, instalado como `/usr/share/applications/luna.desktop`).
- Límites honestos: los videos y SVG no tienen miniatura real dentro de la ventana (SVG no carga por PIL); la pausa inteligente automática necesita `xdotool` en Garuda, si no, la pausa es manual con el botón. `luna.py` usa `pkill -f mpv` para parar el fondo, que es muy amplio y también mataría un mpv abierto para ver un video (en el uso normal de Luna en su Garuda no ha dado problema).

### Instalador — solo 3 pasos
1. **Instalar:** póster limpio de bienvenida (el original del gatito morado) con dos botones grandes con icono: 🟡 Instalar Arch Pacman y 🌀 Instalar .deb Debian Ubuntu. La contraseña no se pide en la terminal: va al instalador por `pkexec` (ventanita gráfica del sistema). En Arch compila con `makepkg` sin `-i` y luego instala con `pkexec pacman -U`; en .deb con `pkexec dpkg -i`. Si no hay pkexec, cae al método anterior y lo dice claro. Nunca finge éxito.
2. **Proceso:** barrita animada despacio, 1% cada 700 ms hasta el 90% mientras instala de verdad, salta al 100% al terminar; texto animado "Cargando... Instalando Luna..." y brillo que cruza la barra. Imagen de instalado grande (700×500, ventana 800×940). La imagen del 65% se quitó del todo del instalador y del PKGBUILD — no volver a ponerla.
3. **Continuar / Finalizar:** botón grande **"▶ Continuar — Abrir Luna"** que cierra el instalador y abre el programa Luna.
- La ventanita del instalador solo sale si zenity está instalado; zenity ya se agregó a los depends del PKGBUILD. El comando único corregido para Garuda empieza instalando zenity (ver "Comandos" abajo).
- Bienvenida ASCII en la terminal: `luna_ascii.py` + `luna_ascii.txt` (póster en ASCII, 110 columnas, morado sobre negro). Limpia la pantalla, muestra "Bienvenido a Luna", la versión y "Hecho por Vega & Kiki / Guzman", pregunta `¿Quieres instalar Luna? [S/n]:`; si dice que sí, corre `sudo pacman -S luna` **en la terminal** (así lo pidió Fernando para esta versión); si pacman no encuentra el paquete, lo dice claro y ofrece el respaldo de Luna Launcher (makepkg), sin fingir éxito; después abre `luna-gui`. Fotos: `~/workspace/luna_terminal.png` (51K, terminal morada) y `~/workspace/luna_ascii_negro.png` (53K, terminal negra). Fernando aprobó el 24 nov 2026: "Si perfecto se ve hermoso ya forma de programa real".

### Comandos
- **Instalar en Garuda (comando único corregido, con zenity primero):**
  `sudo pacman -S --needed --noconfirm zenity && curl -L https://muse.ai/files/1462504743611334/1166286489233473/g4n3wybfgmxan65irgw0afkq/luna-arch.zip -o ~/Descargas/luna-arch.zip && cd ~/Descargas && unzip -o luna-arch.zip && makepkg -si && bash ~/Descargas/luna-installer.sh` (si makepkg pregunta si reinstala, decir que sí). Los enlaces viejos de Muse vencen 24–26 nov 2026; no reutilizarlos, hay que generar un enlace nuevo.
- **Instalar cuando esté en repo (todavía no funciona):** Arch `sudo pacman -S luna`; Debian/Ubuntu `sudo apt install luna`.
- **Desinstalar (agregado al README de GitHub el 25 nov 2026, con iconos):**
  - 🟡 En Arch: `sudo pacman -Rns luna`
  - 🌀 En Debian / Ubuntu: `sudo apt remove --purge luna`
  - 🧹 Para borrar también su configuración, en los dos: `rm -rf ~/.config/luna`
  - Con eso Luna se borra completa, sin dejar nada.
- **Probar el fondo (ya probado en su Garuda):** `luna set ~/Vídeos/claude-chan-afternoon-daydream-moewalls-com.mp4` (la carpeta es Vídeos con acento, no Videos).
- **Borrar archivos viejos de Luna que daban conflicto (dado el 24 nov 2026, sin resultado pegado todavía):** primero `sudo pacman -Rns luna`, luego `sudo rm -f /usr/bin/luna /usr/bin/luna-gui /usr/share/applications/luna.desktop /usr/share/kservices5/ServiceMenus/luna-clic-derecho.desktop && rm -rf ~/.config/luna`.

### Archivos principales en `~/workspace/luna/`
- Código: `luna.py` (comandos set/stop/list/status/version, mpvpaper en Wayland y xwinwrap en X11, `VERSION = "1.0-beta"`), `luna_gui.py` (63K, ventana principal), `luna-installer-gui.py` (instalador gráfico en 3 pasos), `luna-installer.sh` (respaldo zenity/terminal, con `--no-markup` por el `&` de Vega & Kiki), `luna-install.sh` (comando único), `luna-instalar-programa.sh` (instalador limpio: descarga a carpeta temporal, nunca a ~/Descargas, instala con `sudo pacman -U`, limpia y abre Luna), `install.sh`, `luna_ascii.py` + `luna_ascii.txt`.
- Empaquetado: `PKGBUILD` (`pkgver=1.0_beta`, `pkgrel=1`, 19 sources / 19 SKIP, instala en `/usr/bin/luna`, `/usr/bin/luna-gui`, `/usr/lib/luna/`, `/usr/share/luna/` imágenes, `/usr/share/applications/luna.desktop`, `/usr/share/kservices5/ServiceMenus/luna-clic-derecho.desktop`, `/usr/lib/systemd/user/luna.service`), `build-deb.sh`, `debian/control` (todavía con marcadores Maintainer `fernando@example.com`, Homepage `example.com` cuando se revisó por última vez), `debian/rules`, `luna_0.1.0-beta_all.deb` (compilado 21 nov 2026, solo Debian/Ubuntu), `luna_0.1.0-beta_all/`.
- Escritorio/servicio: `luna.desktop`, `luna-utilidades.desktop`, `luna-clic-derecho.desktop`, `luna.service` (ExecStart `/usr/bin/luna`).
- Imágenes: `81630_0_1xuc.webp` (póster original), `poster_limpio.png` (1.8M), las 4 imágenes v1.0 beta corregidas (ver abajo), `backup-imagenes-0.1.0/` (originales que decían "Beta 0.1.0-beta").
- Docs: `PAGINA_LUNA.md` (descripción completa), `BLOCK_LUNA.md` (bloque para la página, con marcador `COMANDO_DE_INSTALACION_AQUI`; copia en `~/workspace/your_files/Bloque luna para nuestra pagina.md`), `ARCHIVO_LUNA.md`, `COMPARACION_LUNA.md`, `README.md`, `LUNA_TODO_ARCHIVADO.md` (este archivo).
- Repo local: `repo/` (Debian), `repo-arch/` (estructura Pacman lista, `x86_64/`, `README.md`; el host sigue siendo el marcador `TU-SERVIDOR`).
- Verificado 25 nov 2026: `py_compile` OK en `luna_gui.py`, `luna.py`, `luna-installer-gui.py` y `luna_ascii.py` (no se editó código, solo este documento).

### Zip — Luna Launcher 3
- `~/workspace/luna-launcher3.zip`, **3.4M (3,613,343 bytes), 30 archivos**, reconstruido el 24 nov 2026 ~18:37. Incluye `luna-install.sh` y las 4 imágenes corregidas; ninguna fuente del PKGBUILD falta; los .py compilan.
- **Las 4 imágenes nuevas ya dicen "v1.0 beta" por dentro** (antes decían "Beta 0.1.0-beta"): `luna-1.0-beta-paso1-instalar.webp`, `luna-1.0-beta-paso2-instalando.webp`, `luna-1.0-beta-paso3-completa.webp`, `luna-1.0-beta-instalado-carrusel.webp` (en `~/workspace/luna/`). Queda un parche apenas perceptible en paso3 a zoom 2x, invisible a tamaño normal. El zip viejo del 24 nov 2026 08:02 se guardó como `~/workspace/luna-launcher3-2026-11-24-0802.zip`.
- **El zip nuevo todavía NO está subido a ningún enlace en vivo y NO hay comando nuevo todavía** — los enlaces temporales viejos de Muse vencen 24–26 nov 2026. El envío de las 07:00 del 25 nov necesita una subida nueva y la aprobación de Fernando para subirla (la negó dos veces el 24 nov 2026).
- El último nombre que Fernando eligió el 23 nov 2026 para la versión corregida es **"Luna correccion 3"** (reemplaza a "Luna 2" y "Luna 3").

### Página web — artifact `luna-pagina`
- Link público: https://muse.ai/s/luna-pagina-xuxd6xmxrxasxu6dxa/RY9iCCORZD6v1F1k4--FBJ0piZ75ViJHge5RKrUgmRI
- Tema morado (#1e1033, botones #7c3aed, texto blanco), póster grande limpio arriba, luego terminal ASCII de bienvenida en caja negra, ¿Qué es Luna? con todos los formatos, Instalación en solo 3 pasos (con las 4 imágenes del proceso), Funciones con un icono por botón, Mejoras de video (sin el nombre Smart Video), Cómo se instala con botones Copiar, pie Hecho por Vega & Kiki / Guzman.
- **Botones Chaotic-AUR y Flatpak** (añadidos 24 nov 2026): en Paso 1 junto a Arch Pacman y .deb, con borde punteado y etiqueta amarilla "Próximamente"; en Cómo se instala cada uno tiene su comando con botón Copiar: Chaotic-AUR `sudo pacman -S luna` (con el repo Chaotic-AUR activado) y Flatpak `flatpak install flathub io.github.guzmankaza.Luna`. La página dice en tres lugares que **todavía no funcionan** porque Luna no está publicada en Chaotic-AUR ni en Flathub.
- La sección "Resumen completo de Luna" se añadió el 24 nov 2026 16:11 a petición de Fernando y se quitó el mismo día 16:13 a petición suya; la página quedó sin resumen. Fernando la aprobó: "Se ve genial" y "Si asi mero estaba perfecto".
- Fernando dio luz verde el 24 nov 2026 16:09 para publicar todo ("Luz verde as tu magia mañana la recomiendo con amigos Recuerda solo es beta Pero ya que todo trabaje bien"). Los cambios posteriores al último `artifact.share` (resumen añadido y quitado) fueron solo builds privados — el link público sirve la última versión compartida (con botones Chaotic/Flatpak, sin resumen, que coincide con el estado final). No describir el link público como actualizado por los cambios posteriores hasta un nuevo `artifact.share`.
- El artifact viejo slug `luna` está archivado; el actual es `luna-pagina`.

### GitHub — lunagave/Lunagave, repo PÚBLICO
- Link: https://github.com/lunagave/Lunagave — cuenta **lunagave** (no guzmankaza), branch main. Fernando creó él mismo el repo (es el repo especial de perfil de lunagave: el nombre del repo es igual al usuario). Login guardado en la tarjeta de Muse el 24 nov 2026, con permiso para entrar a GitHub y subir las imágenes.
- **Commits en orden:**
  1. `43959f4b9538f60f4e2ccc4465fb84ea38c69f9b` — "Luna v1.0 beta - fondos animados en Linux" (24 nov 2026 ~16:44): publicación v1.0 beta, 24 archivos de texto, 157 KB. README nuevo estilo página oficial con Chaotic-AUR y Flatpak Próximamente, LICENSE MIT (reemplazó la GPLv3 que había), luna.py, luna_gui.py, instaladores, PKGBUILD, desktop files y docs. El README nuevo reemplazó la plantilla de perfil. Excluidos (límite del conector, solo UTF-8, sin binarios): .webp, .mp4, .deb, zips, `__pycache__`, `backup-imagenes-0.1.0/`, `repo/`, `repo-arch/`.
  2. `baddf9889035853b666373da7f52a48cff07eb7d` — "README más bonito, como la página oficial" (25 nov 2026 ~00:24): título 🌙 LUNA centrado, badges de texto, tabla de funciones con emojis, tabla de formatos, Cómo se usa en 4 pasos, Instalación en 3 pasos, comandos `sudo pacman -S luna` y `sudo apt install luna`, Chaotic-AUR y Flatpak "⏳ Próximamente", tabla de archivos, pie Hecho por Vega & Kiki / Guzman. Fernando: "Guarda la pagina quedo chingona".
  3. `33c1e8982be8e9b92c308032d42ba67d1ae39203` — "Quitar enlace a página oficial hasta tener dominio" (25 nov 2026 ~00:27): se quitó el enlace a la página oficial del README hasta que Fernando tenga un dominio. El README no contiene `muse.ai` ni "página oficial" (salvo el nombre de archivo `PAGINA_LUNA.md` en la tabla de archivos, que es un documento del repo, no un enlace).
  4. `5acfde8d816a7bc0b0b2d8e307054e70257f9ae3` — "Agregar imágenes v1.0 beta de Luna" (25 nov 2026 00:31 CST, por la web de GitHub, verificación de dispositivo ya resuelta): 5 archivos en la raíz del repo: `luna-1.0-beta-paso1-instalar.webp`, `luna-1.0-beta-paso2-instalando.webp`, `luna-1.0-beta-paso3-completa.webp`, `luna-1.0-beta-instalado-carrusel.webp`, `81630_0_1xuc.webp`.
  5. `8a0a648b265b1abbbd0439d4b5c888867fd76725` — "Agregar imágenes al README, como en la página" (25 nov 2026 ~00:36): póster `81630_0_1xuc.webp` centrado arriba, imagen del carrusel en "Cómo se usa", paso1/paso2/paso3 en "Instalación en solo 3 pasos". Sin reponer el enlace a la página oficial.
  6. `aac1dc80a730f8daf839d29ab83c854bf212e2e4` — "Cambiar póster por terminal morada de bienvenida" (25 nov 2026 ~00:39): el póster de arriba del README pasó de `81630_0_1xuc.webp` a `luna_terminal.png`.
  7. `48c5c2ac5454ea9305d51d05c150db8026cc71eb` — "Agregar terminal morada de bienvenida" (25 nov 2026 00:39 CST, por la web de GitHub): archivo `luna_terminal.png` subido al repo.
  8. `7edb78a2c3eab7a1682c4eb368ff6ab5e1e3da30` — "Agregar Desinstalar Luna con iconos" (25 nov 2026 ~01:07): sección `## 🗑️ Desinstalar Luna` en el README, con iconos 🟡 Arch, 🌀 Debian/Ubuntu, 🧹 borrar configuración, y cierre "Con eso Luna se borra completa, sin dejar nada. 🗑️✨".
- **El póster del README es `luna_terminal.png` (la terminal morada de bienvenida, su logo)**, elegido por Fernando el 25 nov 2026 ("La morada es su logo"), cuando se le mostraron las dos: la negra (`luna_ascii_negro.png`) y la morada (`luna_terminal.png`). El póster viejo del gatito (`81630_0_1xuc.webp`) sigue en el repo, pero ya no es el póster del README.
- **Actividad del perfil escondida (25 nov 2026 ~00:48):** Fernando pidió que no se vieran los 8 commits al final. Se activó en Settings > Public profile > Contributions & activity la casilla **"Make profile private and hide activity"**; verificado con "View what others see": ya no se ven las 8 contribuciones de noviembre 2026 ni el gráfico, solo "@lunagave's activity is private". **El repo Lunagave sigue PÚBLICO y visible**; solo la actividad del perfil quedó privada. Fernando sí ve su perfil completo cuando tiene sesión iniciada.
- **Comentarios — NO apagados del todo:** Fernando solo quiere que lo califiquen (estrellas) y genere vistas, sin comentarios por el momento. **Discussions ya está apagado** (la página /discussions da 404). **Issues sigue ACTIVADO** (hay botón "New issue"; 0 issues abiertos) — falta desmarcarlo en Settings > Features. El conector de GitHub no tiene herramienta para cambiar ajustes del repo, así que lo tiene que hacer Fernando en la web, o una tarea de navegador con sesión iniciada. No afirmar que los comentarios están apagados. Las estrellas y las vistas no se pueden apagar, y eso es lo que Fernando quiere.
- Antes de publicar, se le mostró primero a Fernando el link donde está alojado el código fuente. Con el repo público, cualquiera puede ver/descargar, pero solo el dueño puede cambiar el código de su repo; otros solo pueden hacer fork de su propia copia, que no toca su Luna. No darle a nadie acceso de colaborador.
- Sincronización local: staging en `~/workspace/luna-github/`, registro en `~/workspace/luna-github.muse-github-snapshot-sync.json` (6 entradas tras el commit de Desinstalar).

### Estado en su Garuda
- Computadora: Arch Garuda Linux, usuario `kiki`, host `kiki-83b2`, home `/home/kiki`. Su carpeta de videos es `~/Vídeos` con acento.
- **Luna 0.1.0_beta-1 ya se instaló** con makepkg -si el 22 nov 01:42-02:11, después de borrar los archivos viejos `/usr/bin/luna` y `luna.desktop` que daban conflicto.
- **Fondo de video probado y funcionando el 22 nov 02:33:** `luna set ~/Vídeos/claude-chan-afternoon-daydream-moewalls-com.mp4` — el fondo se ve y el video se mueve.
- GUI abierta en su Garuda el 22 nov 21:31-21:40; dijo que funciona sin errores y que Poner Fondo muestra "Listo" en verde.
- El 24 nov 2026 por la noche estaba en el trabajo, dijo que llegaría a casa a las 12; el 25 nov 2026 00:30 confirmó "Estoy en casa" y "Estot en el lapton" (en su laptop).
- Pendiente de confirmar por Fernando en su pantalla tras reinstalar Luna Launcher 3: póster limpio con los dos iconos de instalar, Paso 2 con el prompt gráfico de pkexec (no contraseña en terminal) y la barrita lenta animada, Paso 3 con el botón ▶ Continuar abriendo Luna, GUI solo con el carrusel 3D, Agregar Carpeta solo en la barra superior, sin "Sin carpeta", Funciones dentro de Acerca, sin sonido en Ajustes, Mejoras de video, Luna en Inicio > Utilidades, y clic derecho "Abrir Luna" abriendo la ventana. También pendientes: el resultado de los comandos para borrar archivos viejos (dados 24 nov 00:27) y su respuesta sobre arreglar los botones de arriba a la derecha que se veían cortados en la foto de la GUI.

### Hosting / dominio — decisión pendiente, compra en pausa hasta ~26 nov 2026
- Fernando quiere un dominio para la página oficial de Luna y un hosting donde, cuando dé luz verde, se suba la página ya con los comandos de instalación, para que él después pueda entrar y modificar solo las instrucciones sin dañar el código. Solo cuando tenga dominio volverá el enlace a la página oficial en el README de GitHub.
- **Porkbun es el candidato actual:** Cloud for WordPress (el plan con WordPress, elegido por Fernando el 24 nov 2026), **$30 el primer año con dominio gratis, pero renueva a $120 al año de hosting + la renovación del dominio**. Al principio es más barato que Hostinger, después es más caro (corrección avisada a Fernando el 24 nov 2026 12:36). Precios verificados en https://porkbun.com/products/web_hosting el 24 nov 2026: Static Hosting desde $2.50/mes; Cloud for WordPress desde $2.50/mes el primer año (antes $10.00); en la tabla de comparación el almacenamiento dice "up to 20 GB" y en la tarjeta del plan "up to 40G" (discrepancia sin resolver — no afirmar 40G).
- **Compra en pausa hasta que le paguen, alrededor del 26 nov 2026** (dijo el 24 nov 2026 06:26 "Dame 2 dias que me pagen" y el 14:36 "Gracias solo deja que me pagen para comprar un block para el proyecto"). **No comprar nada ahora. Todavía falta que Fernando diga qué nombre de dominio quiere** (preguntado el 24 nov 2026 12:36, sin respuesta).
- **Hostinger Premium rechazado por caro:** $95.52 en total por 48 meses ($1.99/mes), renueva a $10.99/mes por 12 meses, dominio gratis 1 año, 2 buzones de 1 GB por 1 año. Fernando dijo "Esta muy caro 100".
- Antes eligió GoDaddy (24 nov 2026 02:24) y pidió unos días para buscarlo. También está registrado en Hostinger con guzmankaza@gmail.com (aviso de Google 24 nov 02:15 CST de inicio de sesión con Google en Hostinger.com). Nada subido a GoDaddy, Hostinger, Porkbun ni GitHub Pages. GitHub Pages (gratis, sin dominio) se ofreció como alternativa el 24 nov 2026 16:07. El 24 nov 2026 16:07-16:08 preguntó si, aun sin dominio, toda la página se puede poner en GitHub y subir ahí el zip para que funcionen los botones Flatpak y Chaotic-AUR; se le explicó que GitHub Pages puede alojar la página gratis y el zip puede ir en un repo/release, pero los botones Flatpak/Chaotic-AUR no instalan hasta que Luna esté publicada de verdad en Flathub/Chaotic-AUR.

### AUR y Flatpak — todavía NO publicados ni aprobados
- Luna v1.0 beta ya está en GitHub (código público con licencia MIT), pero **aún no está en AUR ni en Flathub**. Los botones Chaotic-AUR y Flatpak dicen "Próximamente" y sus comandos no instalan todavía (confirmado a Fernando el 25 nov 2026 01:04: Flatpak todavía no está aprobado).
- Lo que aprueba no es el hosting ni el diseño de la página, sino el código fuente público en GitHub con licencia, PKGBUILD/.SRCINFO para AUR y manifest + metainfo para Flathub, construidos desde el fuente.
- **Instrucciones de AUR pendientes:** Fernando pidió el 24 nov 2026 00:26 que cuando Luna esté casi terminada se le den las instrucciones para publicarla en AUR, con un comando fácil de instalar para .deb y para Pacman. Todavía no se han entregado. Orden acordado: **primero AUR**, después repo propio para `sudo pacman -S luna`.
- El `.pkg.tar.zst` todavía no existe: hay que compilarlo en el Garuda de Fernando con `makepkg -si` (esta máquina es Debian, no tiene makepkg), luego copiarlo a `repo-arch/x86_64/` y regenerar la base con `repo-add`. El host del repo sigue siendo el marcador `TU-SERVIDOR`.

### Compromisos pendientes — 25 nov 2026
1. **25 nov 2026 07:00 America/Chicago — enviar Luna Launcher 3** por correo a guzmankaza@gmail.com (asunto "Luna Launcher 3"), cuerpo **solo el comando único de instalación**, sin archivos adjuntos ni explicación. El trabajo debe verificar primero que la versión corregida esté lista (barrita lenta del Paso 2, sin "Sin carpeta", Funciones en el submenú de Acerca, sin sonido en Ajustes, Mejoras de video, póster e imágenes más grandes, v1.0 beta en todos lados, clic derecho "Abrir Luna", imágenes que dicen v1.0 beta por dentro, zip reconstruido) y **generar un enlace/comando NUEVO en vivo** — los enlaces temporales viejos vencen 24–26 nov 2026 y no deben reutilizarse. Si la versión no está lista, no enviar una versión incompleta. Nota: Fernando negó la aprobación de subida a Muse dos veces el 24 nov 2026 (00:24 y 02:02 CST), así que el envío de las 07:00 todavía necesita una aprobación de subida para funcionar.
2. **25 nov 2026 15:00 America/Chicago — enviar toda la información de la página de Luna** (desde `PAGINA_LUNA.md`, el link público de luna-pagina, estado de hosting/dominio, requisitos de AUR/Flatpak). No publicar nada ni actualizar el link público sin su luz verde.
- Correos de Fernando: guzmankaza@gmail.com (principal, Gmail conectado) y morttisfer@gmail.com (segundo, dado 24 nov 2026).
- El compromiso original del 22 nov 2026 09:00 ("enviar todo compilado") ya se completó el 22 nov 2026 08:56; no reenviarlo.

### Preguntas abiertas (sin respuesta de Fernando)
- ¿Quitar también "Smart Video Wallpaper de KDE" de `COMPARACION_LUNA.md`? (preguntado 24 nov 2026 01:59; ahí es el nombre del programa de KDE con el que se compara Luna).
- ¿Arreglar los botones de arriba a la derecha de la GUI que se veían cortados en la foto de prueba? (preguntado 24 nov 2026 01:39).
- ¿Qué nombre de dominio quiere para la página oficial de Luna? (preguntado 24 nov 2026 12:36).
- Objetivo de intereses: Fernando dijo el 14 nov 2026 "Quiero empezar un objetivo de intereses" pero nunca especificó el interés. No crear el objetivo ni inventar el interés hasta que él elija uno.
- Problema con los audífonos (14 nov 2026): síntoma desconocido (no se escucha / se corta / muy bajo); no asumir uno. No reabrir estos dos temas sin que él los mencione, y solo hablar de Proyecto Luna.

## Resumen (21 nov 2026 — estado inicial, ver la actualización del 25 nov 2026 arriba)

Luna es un proyecto para poner fondos de pantalla animados, fácil y sin plugins.
Para Arch (Pacman) y Debian/Ubuntu (.deb).
Hace algo similar a Hidamari y al fondo de video de KDE, pero fácil para el usuario común.

## Archivos de resumen

- `ARCHIVO_LUNA.md` — los 3 pasos con imágenes y las funciones.
- `COMPARACION_LUNA.md` — comparación Luna vs Hidamari vs el fondo de video de KDE.

## Paso 1 — Base del proyecto

- Póster original: `../user/files/81630_0_1xuc.webp`
- Video del póster: `media-generation-luna-paso1-poster-0-bef26f93-8163-4f69-8e35-5f7f795baed1.mp4`

## Paso 2 — Diseño del instalador

- Instalando 65% con barrita: `media-generation-luna-instalando-proceso-0-f3b3df9d-f2c3-4ba1-bcb5-04792240cd4e.webp`
- Instalando 100% completado: `media-generation-luna-instalando-0-9189c024-59e0-4561-81d0-d789d24136e2.webp`
- Video del 1 al 100: `media-generation-luna-instalando-1-100-0-88194f11-e317-4a08-8d46-1dcd4d49950e.mp4`
- Video instalador termina y se abre el programa: `media-generation-luna-instalador-abre-programa-0-6256ca65-03b9-45f1-a10b-5473374cf697.mp4`

## Paso 3 — Interfaz y herramientas

- Interfaz Biblioteca con carrusel: `media-generation-luna-interfaz-biblioteca-carru-0-d4ecef1d-d3e4-4f88-ad0f-ff0eb604b6c9.webp`
- Ajustes abre otra pantalla: `media-generation-luna-interfaz-principal-sin-aj-0-28c0b2be-1eb8-4c11-b15e-bedab79e8958.webp`
- Botón Poner Imagen en el Fondo de Pantalla: `media-generation-luna-boton-poner-fondo-0-11ddadff-28ca-482e-a90a-c26fadac4ebb.webp`
- Carrusel arriba, vista previa abajo: `media-generation-luna-carrusel-arriba-vista-aba-0-3c945284-96d3-4a07-bf84-4484e9565451.webp`
- Primera interfaz de referencia: `../user/files/81463_3_hnje.webp`
- Versión con emulación, NO usar: `media-generation-luna-interfaz-emulationstation-0-8399930c-9287-4ec2-b07a-749733b8a8cb.webp`

## Funciones del programa

- Instalador fácil .deb / .pacman, sin terminal, al terminar abre Luna.
- Clic derecho en escritorio: Poner Luna como Fondo de Escritorio, Establecer Imagen como Fondo, Establecer Video como Fondo, Abrir con Luna Biblioteca.
- Automático al elegir video o imagen en la Biblioteca.
- Todos los formatos: JPG, PNG, WEBP, GIF, BMP, SVG / MP4, MKV, WEBM, MOV, AVI.
- Mejoras de video: escalado IA, nitidez, estabilización, reducción de ruido, HDR, pausa inteligente, volumen, multi-monitor.
- Archivo de funciones: `media-generation-luna-clic-derecho-fondo-automa-0-651e12c0-6c62-4cd6-8dee-7c0085df28d9.webp`

## Ventana GUI archivada 22 nov 2026
- `luna_gui.py` (19K, probado con py_compile OK) — ventana Luna Beta 0.1.0-beta, con imágenes archivadas: póster gatito morado en Acerca, 7 imágenes de diseño en "Ver diseño de Luna", carrusel arriba con miniaturas reales JPG/PNG/WEBP/GIF/BMP, vista previa abajo, botón Poner Imagen en el Fondo de Pantalla (llama a `luna set`), Ajustes en ventana aparte con Cerrar/Guardar, Próximamente, Acerca, y abajo "Hecho por Vega & Kiki". Videos y SVG siguen con texto de respaldo. Abrir con `python3 luna_gui.py`.
- `luna-installer.sh` — instalador con ventanita zenity del 1 al 100, arreglado con --no-markup por el `&` de Vega & Kiki.
- Rediseño 22 nov 2026: `luna_gui.py` ya no es gris estilo Windows 98; ahora es morado oscuro Luna (#1e1033, botones #7c3aed, texto blanco), con el póster del gatito en la cabecera. Probado con py_compile y 10 s bajo Xvfb sin errores.
- Menú Utilidades 22 nov 2026: `luna-utilidades.desktop` con Exec=luna-gui, Categories=Utility; el PKGBUILD (pkgrel=2) instala `luna_gui.py` como /usr/bin/luna-gui y ese .desktop como /usr/share/applications/luna.desktop, y añade tk y python-pillow a depends. Simulación de instalación verificada en /tmp/pkgroot. makepkg no se pudo probar aquí (VM Debian, no hay makepkg); hay que compilarlo en Garuda.

## No usar

- `media-generation-luna-comparacion-hidamari-smar-0-a38b4f06-11fa-4739-b103-9e0c9a563096.webp` — imagen generada equivocada, de estudiar en casa vs biblioteca. La comparación correcta está en `COMPARACION_LUNA.md`.

## Instalación como programa — 22 nov 2026 (noche)
- PKGBUILD pkgrel 4: instala todo en su lugar (/usr/bin/luna, /usr/bin/luna-gui, /usr/lib/luna/, /usr/share/luna/ con las 8 imágenes, menú Utilidades, clic derecho KDE, servicio). Corregido: luna_gui.py ahora busca las imágenes primero en /usr/share/luna/ (antes solo junto al script, y tras instalar no las encontraba); luna.service ahora apunta a /usr/bin/luna (antes /usr/local/bin/luna).
- `luna-instalar-programa.sh`: descarga el paquete a una carpeta temporal, instala con `sudo pacman -U`, limpia, no deja archivos sueltos en ~/Descargas. El enlace real del paquete aún no existe (falta servidor).
- `repo-arch/`: estructura del repo Pacman lista (x86_64/luna.db.tar.gz con Luna, README con las 2 formas de instalar). Falta el .pkg.tar.zst, que solo se puede compilar en Garuda con `makepkg -si` (esta máquina es Debian, no hay makepkg). Nada publicado en AUR/GitHub.

## Actualización — 24 nov 2026

### Instalador — solo 3 pasos
1. **Instalar:** el link solo pide el comando. La contraseña no se escribe en la terminal: va al instalador por `pkexec`, la ventanita gráfica del sistema, una sola vez. Si no hay pkexec, cae a `sudo` y lo dice claro. Póster limpio, sin los logos de Pacman Arch ni .deb dentro de la imagen (recortado al 82% en memoria, el archivo original no se toca), y dos botones grandes con icono: 🟡 Instalar Arch Pacman y 🌀 Instalar .deb Debian Ubuntu.
2. **Proceso / barra:** barrita animada despacio, 1% cada 700 ms hasta el 90% mientras instala de verdad, y salta al 100% al terminar. Texto animado "Cargando... Instalando Luna...". En Arch compila con `makepkg` sin `-i` (no pide sudo) y luego instala el paquete con `pkexec pacman -U`. En .deb igual, con `pkexec dpkg -i`.
3. **Continuar / Finalizar:** botón grande "▶ Continuar — Abrir Luna" que cierra el instalador y abre el programa Luna. El respaldo zenity/terminal (`luna-installer.sh`) también termina con Continuar y abre `luna-gui`.
- Al instalar, Luna queda en el **menú Utilidades** (`luna-utilidades.desktop`, `Exec=luna-gui`, `Categories=Utility;`, instalado como `/usr/share/applications/luna.desktop`).
- **Clic derecho en el escritorio:** sobre una imagen o un video, "Poner con Luna" (`luna set %f`) la pone como fondo ahí mismo; también "Abrir Biblioteca de Luna" (`luna list`). `luna-clic-derecho.desktop`, instalado por el PKGBUILD en `/usr/share/kservices5/ServiceMenus/`. *(Corregido después: ver la actualización del 25 nov 2026 arriba — la segunda acción ahora es "Abrir Luna" con `luna-gui`.)*
- PKGBUILD: `0.1.0_beta`, **pkgrel 5**. Corrección del 23 nov: la imagen del 65% ya no se usa ni se lista en `source` (antes `makepkg` fallaba porque la pedía y no estaba en el zip).
- `luna-install.sh`: comando único de instalación. Descarga el zip a `/tmp/luna-install`, descomprime, `makepkg`, instala con `pkexec pacman -U`, corre el instalador gráfico y limpia. Apunta a `luna-launcher3.zip` (última versión corregida).
- Límite honesto: el flujo con `pkexec` no se pudo probar en esta máquina (Debian, sin makepkg ni pkexec de Arch); en Garuda debe salir la ventanita gráfica del sistema.

### Ventana GUI — cambios del 24 nov 2026
- **Barrita del paso 2 más lenta y animada:** 1% cada 700 ms (antes 300 ms), con brillo que corre más despacio por la barra.
- **Sin "Sin carpeta":** la etiqueta de la barra superior queda vacía al inicio y solo muestra la ruta cuando se elige una carpeta con Agregar Carpeta.
- **Funciones de Luna dentro de Acerca, como submenú:** se quitó el botón aparte "✨ Funciones de Luna" de la ventana principal. Acerca ahora tiene dos pestañas arriba: 🐱 Acerca (póster grande + toda la información) y ✨ Funciones (las 14 funciones del Paso 4, de `PAGINA_LUNA.md` / `COMPARACION_LUNA.md`, sin video de YouTube ni página web como fondo).
- **Sin sonido en Ajustes:** salieron el checkbox de volumen/silencio y el deslizador de volumen de Ajustes. El sonido queda solo en la ventana principal (botón Sonido/Silencio + deslizador de la barra superior).
- **Mejoras de video activadas en Ajustes:** nueva sección "Mejoras de video" con interruptores de verdad, guardados en `~/.config/luna/ajustes.json`: mejoras de video activadas, Escalado IA, Nitidez, Estabilización, Reducción de ruido, HDR y Desenfoque (blur). Todos activados por defecto salvo blur. También se activaron Pausa inteligente por batería y por pantalla apagada, Multi-monitor e Inicio automático.
- **Póster e imágenes más grandes:** Acerca, póster de 440×660 a **560×780**, ventana de 660×880 a 720×960; cabecera de la GUI, póster de 72×72 a **120×120**; instalador paso 1, póster de 680×380 a **720×500**, ventana de 800×940.
- Se mantiene: solo carrusel 3D (sin Biblioteca, sin Vista previa, sin cuadrícula), botón 🖼 Poner Imagen en el Fondo de Pantalla, Agregar Carpeta solo en la barra superior, búsqueda, Aleatorio, Agregar Fondo, Quitar, Ajustes aparte, Acerca aparte, tema morado moderno con iconos, y al final "Hecho por Vega & Kiki / Guzman".
- Probado: `py_compile` OK en `luna_gui.py` y `luna-installer-gui.py`; ventana principal bajo Xvfb sin "Sin carpeta" ni botón Funciones suelto; instalador `--demo --auto` llega al 100% y cierra, salida 0.

### Bienvenida ASCII en la terminal — 24 nov 2026
- `luna_ascii.py` + `luna_ascii.txt`: estilo shell, en la terminal. Al pegar el comando se limpia la pantalla, se ve el póster de Luna en ASCII (solo caracteres `@ # * + = - : .`, en morado sobre fondo negro), y abajo dice "Bienvenido a Luna", "LUNA Beta 0.1.0-beta", "Fondos de pantalla animados, fácil y sin plugins" y "Hecho por Vega & Kiki / Guzman".
- Abajo pregunta: `¿Quieres instalar Luna? [S/n]:`
- Si dice que sí, hace `sudo pacman -S luna` en la terminal (la contraseña se pide ahí, en la terminal). Si pacman dice que no encontró el paquete, lo dice claro y ofrece instalar con Luna Launcher (makepkg), sin fingir que quedó instalada. Después de instalar, abre Luna con `luna-gui`. Si dice que no, muestra "No se instaló Luna." y sale.
- Probado con `n` y con `s` con un pacman falso que falla: el flujo de la pregunta funciona; no se instaló nada de verdad en esta máquina Debian.

### Guzman abajo, en todo el programa
- Abajo, en todo el programa igual: **"Hecho por Vega & Kiki / Guzman"**. En la ventana de Luna (pie y Acerca), en el instalador (pasos 1 y 3), en la terminal ASCII, en `luna.py`, en `luna-installer.sh` y `luna-instalar-programa.sh`, y en los documentos (`PAGINA_LUNA.md`, `repo-arch/README.md`).

### Estado — 24 nov 2026
- Luna sigue siendo **Beta** (0.1.0-beta), solo para nosotros por ahora. Será **Beta pública** cuando todo esté mejorado, para que la comunidad la pruebe.
- Cuando sea oficial, el orden es: **primero AUR**, después repo propio para `sudo pacman -S luna`. Después se darán las instrucciones para publicarlo en AUR, con un comando fácil de instalar para .deb y para Pacman.
- **Nada publicado en AUR/GitHub todavía.** *(Ya no es así: ver la actualización del 25 nov 2026 arriba — Luna v1.0 beta ya está publicada en GitHub, repo público lunagave/Lunagave; en AUR sigue sin estarlo.)* El `.pkg.tar.zst` aún no existe: hay que compilarlo en el Garuda de Fernando con `makepkg -si` (PKGBUILD pkgrel 5), y antes de publicar hay que mostrarle primero el link donde estará alojado el código fuente.
- Fernando: usuario común en Linux, ya camino a intermedio. Instala con comandos, usa la terminal, prueba Luna y estudia el código. Luna es suya; el trabajo es ayudarlo a hacerla.
- Envío pendiente: Luna Launcher 3, mañana 25 nov 2026 a las 7, por correo a guzmankaza@gmail.com, solo con el comando.

### Archivos actuales en `~/workspace/luna/` (24 nov 2026)
- `81630_0_1xuc.webp` — póster original de Luna (gatito morado en la luna creciente), foto de bienvenida del instalador.
- `ARCHIVO_LUNA.md` — los 3 pasos con imágenes y las funciones.
- `COMPARACION_LUNA.md` — comparación Luna vs Hidamari vs el fondo de video de KDE.
- `LUNA_TODO_ARCHIVADO.md` — este archivo: todo el proyecto archivado.
- `PAGINA_LUNA.md` — descripción completa del programa para la página.
- `README.md` — resumen del proyecto.
- `PKGBUILD` — paquete Arch, 0.1.0_beta, pkgrel 5 (sin la imagen del 65%).
- `build-deb.sh` — construye el .deb de Luna.
- `debian/control`, `debian/rules` — archivos del paquete .deb.
- `install.sh` — instalador general del proyecto.
- `luna.py` — programa de fondo: comandos `set` / `stop` / `list` / `status`, pone video o imagen con mpv.
- `luna_gui.py` — ventana principal de Luna (tkinter, carrusel 3D, Ajustes, Acerca con submenú Funciones, mejoras de video).
- `luna-installer-gui.py` — instalador gráfico en 3 pasos (Instalar, proceso con barrita lenta, Continuar).
- `luna-installer.sh` — instalador con ventanita zenity (respaldo) o terminal.
- `luna-install.sh` — comando único de instalación (descarga el zip, makepkg, pkexec, instalador).
- `luna-instalar-programa.sh` — instalador limpio del paquete, sin dejar archivos sueltos en Descargas.
- `luna_ascii.py` — bienvenida ASCII en la terminal (pregunta si instalar Luna, luego `sudo pacman -S luna`).
- `luna_ascii.txt` — el póster de Luna en ASCII, para la terminal.
- `luna.desktop` — lanzador de Luna.
- `luna-utilidades.desktop` — Luna en el menú Utilidades (Exec=luna-gui).
- `luna-clic-derecho.desktop` — menú de clic derecho en KDE ("Poner con Luna", "Abrir Luna" — corregido; antes decía "Abrir Biblioteca de Luna").
- `luna.service` — servicio de usuario para que Luna arranque sola.
- `luna_0.1.0-beta_all.deb` — paquete .deb ya compilado (para Debian/Ubuntu, no para Garuda).
- `luna_0.1.0-beta_all/` — carpeta del paquete .deb compilado.
- `repo/` — repo Debian con el .deb, `Packages` y `Packages.gz`.
- `repo-arch/` — repo Pacman (estructura lista, falta el .pkg.tar.zst; hay un `FALTA-el-paquete.txt`).
- `media-generation-luna-*.webp` — imágenes de diseño archivadas (instalando 100%, biblioteca/carrusel, botón Poner Fondo, clic derecho, interfaz principal). La imagen del 65% ya no se usa.
- `media-generation-luna-*.mp4` — videos archivados (póster paso 1, instalando 1-100, instalador que termina y abre el programa).
- `media-generation-*.json` — datos de generación de las imágenes y videos.
- `media-generation-last-upload-handles.json` — últimos enlaces de subida.
- `.thumbnails/` — miniaturas de las imágenes generadas.

## Bloque para la página — 24 nov 2026
- `BLOCK_LUNA.md` — bloque "Bloque luna para nuestra pagina": resumen de todo para la página. Empieza con el póster ASCII en la terminal, morado sobre fondo negro, con la pregunta ¿Quieres instalar Luna? Luego qué es Luna, Beta 0.1.0-beta, instalación en 3 pasos con iconos, funciones con iconos por botón, Mejoras de video (sin el nombre Smart Video, solo sus funciones), cómo se instala, y abajo Hecho por Vega & Kiki / Guzman.
- Copia del bloque: `~/workspace/your_files/Bloque luna para nuestra pagina.md`.
- Resumen en imagen morada: `~/workspace/luna_resumen_morado.png` (póster limpio sin logos, 3 pasos, funciones, mejoras de video, terminal ASCII, Hecho por Vega & Kiki / Guzman).
- Foto terminal ASCII: `~/workspace/luna_terminal.png`.
- Foto ventana principal: `~/workspace/luna_foto.png`.
- Fotos instalador 3 pasos: `~/workspace/luna_instalador_paso1.png`, `luna_instalador_paso2.png`, `luna_instalador_paso3.png`.
